ForgeTrace v0.3.6 read-only audit evidence

Audited ZIP SHA-256: 98045cbe2cec76842f316c67f26f3b57bd0ba21a903eac0ba1bf0eebecc65b24

The original ZIP was not modified. Test repositories and scripts operated only in /mnt/data/forgetrace-v036-audit.

Key files:
- adversarial-results.json: destructive restore and import reproductions
- multiprocess-results.json: four-process contention reproductions
- additional-results.json: nested metadata, backup recovery, startup relink
- transaction-results.json: filesystem/history divergence and empty directories
- performance-results.jsonl and ui-scale*.jsonl: scale measurements
- unit-test-full.log and browser-tests.log: packaged test results
- ui-tree-order-result.json: detached parent/child UI order
- ui-folder-action-result.txt: disabled folder rename/delete
- localstorage-result.txt: successful copy misreported as failed
- coverage.txt and complexity.json: test/maintainability evidence
- package-sha256.txt and manifest-verification.json: package integrity
